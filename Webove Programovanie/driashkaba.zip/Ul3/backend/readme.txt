start backend server: 
	1. in backend dir in the console "npm install" (to install all dependencies)
	2. in backend dir in the console "npm run dev" (to start server)
	3. If there is a message "Server listening on port 3001(default port on .env file) then everything is working