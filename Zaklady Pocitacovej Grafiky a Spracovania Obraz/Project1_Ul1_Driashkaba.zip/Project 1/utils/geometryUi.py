from tkinter import *

def drawLine(canvas, v1, v2):
    v1x, v1y = v1[0], v1[1]
    v2x, v2y = v2[0], v2[1]

    canvas.create_line(v1x, v1y, v2x, v2y, fill="blue")

def drawFace(canvas, vertices, faceIds):
    id1, id2, id3 = faceIds
    v1, v2, v3 = vertices[id1-1], vertices[id2-1], vertices[id3-1] 

    drawLine(canvas, v3, v1)
    drawLine(canvas, v1, v2)
    drawLine(canvas, v2, v3)

def drawObject(canvas, vertices, faces):
    for face in faces:
        drawFace(canvas, vertices, face)